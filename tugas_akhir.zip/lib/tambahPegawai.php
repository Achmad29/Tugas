<?php

    include "koneksi.php";
    $nama      = $_POST['namaPegawai'];
    $posisi    = $_POST['PosisiPegawai'];
    $gaji      = $_POST['gajipegawai'];

    $connect->query("INSERT INTO tb-pegawai (nama, posisi, gaji)
                    VALUES ('".$nama."','"$posisi."'.$gaji."')");

 ?>                   