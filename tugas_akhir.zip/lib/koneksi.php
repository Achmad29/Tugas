<?php 

  $connect = new mysqli ("localhost", "root","","db_pegawai");
  {
    echo "Koneksi Gagal";
    exit();
  }
  ?>