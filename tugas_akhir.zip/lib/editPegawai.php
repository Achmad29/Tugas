<?php

    include "koneksi.php";
    $id     = $_POST['id'];
    $nama   = $_POST['posisiPegawai'];
    $gaji   = $_POST['gajipegawai'];

    $connect->query("UPDATE tb_pegawai SET nama= '".$nama."',
        posisi = '".$posisi."', gaji = '".$gaji."' WHERE id=".$id);

?>        